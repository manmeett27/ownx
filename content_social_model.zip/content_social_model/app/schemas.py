"""
Pydantic schemas — define the shape of data going in/out of the API.
"""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, ConfigDict

from app.models import MediaType


# ---------- User ----------
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    interests: List[str] = []  # e.g. ["travel", "food"]


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: EmailStr
    interests: str
    created_at: datetime


# ---------- Post ----------
class PostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    owner_id: int
    media_type: MediaType
    file_path: str
    description: str
    interests: str
    category: str
    likes_count: int
    created_at: datetime


class PostWithScore(PostOut):
    score: Optional[float] = None  # similarity/relevance score, set by recommender


class LikeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    post_id: int
