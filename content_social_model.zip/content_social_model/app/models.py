"""
ORM models for the content-based social media platform.

User      -> a person on the platform, has a list of interests
Post      -> a piece of media (image or short video) a user uploads,
             tagged with description + interests + category so the
             recommendation engine has content to work with
Like      -> tracks which user liked which post (used to personalize feed)
"""
import enum
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, DateTime, ForeignKey, Enum, UniqueConstraint
)
from sqlalchemy.orm import relationship

from app.database import Base


class MediaType(str, enum.Enum):
    image = "image"
    video = "video"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    # comma-separated interests e.g. "travel,food,coding"
    interests = Column(String(500), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    posts = relationship("Post", back_populates="owner", cascade="all, delete-orphan")
    likes = relationship("Like", back_populates="user", cascade="all, delete-orphan")


class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    media_type = Column(Enum(MediaType), nullable=False)
    file_path = Column(String(300), nullable=False)   # where the uploaded file lives
    thumbnail_path = Column(String(300), nullable=True)

    description = Column(Text, default="")
    # comma-separated tags e.g. "sunset,beach,travel"
    interests = Column(String(500), default="")
    category = Column(String(50), index=True, nullable=False)  # e.g. "Travel", "Food", "Comedy"

    likes_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    owner = relationship("User", back_populates="posts")
    likes = relationship("Like", back_populates="post", cascade="all, delete-orphan")


class Like(Base):
    __tablename__ = "likes"
    __table_args__ = (UniqueConstraint("user_id", "post_id", name="unique_user_post_like"),)

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    post_id = Column(Integer, ForeignKey("posts.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="likes")
    post = relationship("Post", back_populates="likes")
