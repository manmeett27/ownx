"""
Content-based social media platform — API layer.

Run with:
    uvicorn app.main:app --reload

Then open http://127.0.0.1:8000/docs for interactive Swagger UI testing.
"""
import os
import shutil
import uuid
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from app.database import Base, engine, get_db
from app import models, schemas
from app.recommend import ContentRecommender

# Create tables on startup (fine for dev; use Alembic migrations in production)
Base.metadata.create_all(bind=engine)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
ALLOWED_VIDEO_EXT = {".mp4", ".mov", ".webm"}

app = FastAPI(
    title="Content-Based Social Media API",
    description="Instagram-style upload + content-based recommendation engine",
    version="1.0.0",
)


# ----------------------------------------------------------------------
# Users
# ----------------------------------------------------------------------
@app.post("/users/", response_model=schemas.UserOut, tags=["Users"])
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(
        (models.User.username == user.username) | (models.User.email == user.email)
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username or email already registered")

    db_user = models.User(
        username=user.username,
        email=user.email,
        interests=",".join(user.interests),
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@app.get("/users/{user_id}", response_model=schemas.UserOut, tags=["Users"])
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# ----------------------------------------------------------------------
# Posts (upload image / short video)
# ----------------------------------------------------------------------
def _detect_media_type(filename: str) -> models.MediaType:
    ext = os.path.splitext(filename)[1].lower()
    if ext in ALLOWED_IMAGE_EXT:
        return models.MediaType.image
    if ext in ALLOWED_VIDEO_EXT:
        return models.MediaType.video
    raise HTTPException(
        status_code=400,
        detail=f"Unsupported file type '{ext}'. Allowed: images {ALLOWED_IMAGE_EXT}, videos {ALLOWED_VIDEO_EXT}",
    )


@app.post("/posts/", response_model=schemas.PostOut, tags=["Posts"])
def create_post(
    owner_id: int = Form(..., description="ID of the uploading user"),
    description: str = Form("", description="Caption for the post"),
    interests: str = Form("", description="Comma-separated tags, e.g. 'travel,beach'"),
    category: str = Form(..., description="e.g. Travel, Food, Comedy, Fitness"),
    file: UploadFile = File(..., description="Image or short video file"),
    db: Session = Depends(get_db),
):
    owner = db.query(models.User).filter(models.User.id == owner_id).first()
    if not owner:
        raise HTTPException(status_code=404, detail="Owner user not found")

    media_type = _detect_media_type(file.filename)

    ext = os.path.splitext(file.filename)[1].lower()
    unique_name = f"{uuid.uuid4().hex}{ext}"
    dest_path = os.path.join(UPLOAD_DIR, unique_name)
    with open(dest_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    db_post = models.Post(
        owner_id=owner_id,
        media_type=media_type,
        file_path=dest_path,
        description=description,
        interests=interests,
        category=category,
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post


@app.get("/posts/", response_model=List[schemas.PostOut], tags=["Posts"])
def list_posts(skip: int = 0, limit: int = 20, db: Session = Depends(get_db)):
    return db.query(models.Post).order_by(models.Post.created_at.desc()).offset(skip).limit(limit).all()


@app.get("/posts/{post_id}", response_model=schemas.PostOut, tags=["Posts"])
def get_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return post


@app.get("/posts/category/{category}", response_model=List[schemas.PostOut], tags=["Posts"])
def get_posts_by_category(category: str, db: Session = Depends(get_db)):
    return db.query(models.Post).filter(models.Post.category.ilike(category)).all()


@app.get("/users/{user_id}/posts", response_model=List[schemas.PostOut], tags=["Posts"])
def get_posts_by_user(user_id: int, db: Session = Depends(get_db)):
    return db.query(models.Post).filter(models.Post.owner_id == user_id).all()


@app.post("/posts/{post_id}/like", response_model=schemas.LikeOut, tags=["Posts"])
def like_post(post_id: int, user_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")

    existing = db.query(models.Like).filter(
        models.Like.post_id == post_id, models.Like.user_id == user_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Already liked")

    like = models.Like(user_id=user_id, post_id=post_id)
    db.add(like)
    post.likes_count += 1
    db.commit()
    db.refresh(like)
    return like


# ----------------------------------------------------------------------
# Content-based recommendations
# ----------------------------------------------------------------------
@app.get("/posts/{post_id}/similar", response_model=List[schemas.PostWithScore], tags=["Recommendations"])
def similar_posts(post_id: int, top_n: int = 5, db: Session = Depends(get_db)):
    """Find posts with similar content (description + interests + category)."""
    all_posts = db.query(models.Post).all()
    if not any(p.id == post_id for p in all_posts):
        raise HTTPException(status_code=404, detail="Post not found")

    recommender = ContentRecommender(all_posts)
    results = recommender.similar_to_post(post_id, top_n=top_n)

    output = []
    for post, score in results:
        item = schemas.PostWithScore.model_validate(post)
        item.score = score
        output.append(item)
    return output


@app.get("/users/{user_id}/feed", response_model=List[schemas.PostWithScore], tags=["Recommendations"])
def personalized_feed(user_id: int, top_n: int = 10, db: Session = Depends(get_db)):
    """
    Build a personalized, Instagram-style feed for a user using content-based
    filtering: matches the user's declared interests + content of posts
    they've liked against every post's description/interests/category.
    """
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    all_posts = db.query(models.Post).all()
    if not all_posts:
        return []

    liked_ids = [like.post_id for like in user.likes]

    recommender = ContentRecommender(all_posts)
    results = recommender.feed_for_user(
        user_interests=user.interests, liked_post_ids=liked_ids, top_n=top_n
    )

    output = []
    for post, score in results:
        item = schemas.PostWithScore.model_validate(post)
        item.score = score
        output.append(item)
    return output


@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "Content-based social media API is running"}
