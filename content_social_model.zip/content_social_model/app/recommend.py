"""
Content-based recommendation engine.

Why content-based (not collaborative filtering)?
- Works from day 1 with zero interaction history (no "cold start" problem)
- Perfect fit here because every post already carries rich content signals:
  description + interests/tags + category

How it works:
1. Build one "content document" per post:  description + interests + category
2. Vectorize all post documents with TF-IDF
3. Similarity between any two posts = cosine similarity of their TF-IDF vectors
4. "Similar posts" for a post  -> nearest neighbors of that post's vector
5. "Personalized feed" for a user -> build a synthetic query vector from the
   user's stated interests + the content of posts they've liked, then rank
   all posts by similarity to that query vector
"""
from typing import List, Optional, TYPE_CHECKING
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

if TYPE_CHECKING:
    from app.models import Post  # noqa: F401  (type hints only, avoids hard import dependency)


def _post_document(post) -> str:
    """Combine a post's text signals into one document for vectorization."""
    return f"{post.description} {post.interests.replace(',', ' ')} {post.category}"


class ContentRecommender:
    def __init__(self, posts: List["Post"]):
        self.posts = posts
        self.vectorizer = TfidfVectorizer(stop_words="english")
        documents = [_post_document(p) for p in posts] or [""]
        self.matrix = self.vectorizer.fit_transform(documents)

    def similar_to_post(self, post_id: int, top_n: int = 5):
        """Return top_n posts most similar to the given post (excluding itself)."""
        idx = next((i for i, p in enumerate(self.posts) if p.id == post_id), None)
        if idx is None or self.matrix.shape[0] < 2:
            return []
        sims = cosine_similarity(self.matrix[idx], self.matrix).flatten()
        ranked = sorted(
            ((score, i) for i, score in enumerate(sims) if i != idx),
            reverse=True,
        )[:top_n]
        return [(self.posts[i], float(score)) for score, i in ranked if score > 0]

    def feed_for_user(
        self,
        user_interests: str,
        liked_post_ids: Optional[List[int]] = None,
        top_n: int = 10,
    ):
        """
        Build a personalized feed:
        query = user's declared interests + text of posts they've liked.
        Rank every post in the system by similarity to that query.
        """
        liked_post_ids = liked_post_ids or []
        liked_text = " ".join(
            _post_document(p) for p in self.posts if p.id in liked_post_ids
        )
        query_text = f"{user_interests.replace(',', ' ')} {liked_text}".strip()
        if not query_text:
            # No signal at all yet -> fall back to most-liked posts
            ranked = sorted(self.posts, key=lambda p: p.likes_count, reverse=True)
            return [(p, None) for p in ranked[:top_n]]

        query_vec = self.vectorizer.transform([query_text])
        sims = cosine_similarity(query_vec, self.matrix).flatten()
        ranked = sorted(
            (
                (score, i)
                for i, score in enumerate(sims)
                if self.posts[i].id not in liked_post_ids
            ),
            reverse=True,
        )[:top_n]
        return [(self.posts[i], float(score)) for score, i in ranked]
