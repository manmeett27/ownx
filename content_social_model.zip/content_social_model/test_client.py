"""
End-to-end test script.

Run the API first:
    uvicorn app.main:app --reload

Then in another terminal:
    python test_client.py

This walks through the full flow: create users -> upload posts (image/video)
-> like posts -> get similar posts -> get a personalized feed. It prints
each response so you can see exactly what the model returns at every step.
"""
import io
import requests

BASE_URL = "http://127.0.0.1:8000"


def create_fake_image(name: str) -> io.BytesIO:
    """Create a tiny valid in-memory PNG so we don't need real image files to test."""
    # 1x1 transparent PNG, hardcoded bytes
    png_bytes = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108020000009077"
        "53de0000000c4944415408d763f8cfc0c0c00000030101007e0353550000"
        "000049454e44ae426082"
    )
    buf = io.BytesIO(png_bytes)
    buf.name = name
    return buf


def main():
    print("=== 1. Creating users ===")
    alice = requests.post(f"{BASE_URL}/users/", json={
        "username": "alice",
        "email": "alice@example.com",
        "interests": ["travel", "food"],
    }).json()
    print("Alice:", alice)

    bob = requests.post(f"{BASE_URL}/users/", json={
        "username": "bob",
        "email": "bob@example.com",
        "interests": ["comedy", "fitness"],
    }).json()
    print("Bob:", bob)

    print("\n=== 2. Uploading posts ===")
    posts = []
    post_data = [
        {"owner_id": alice["id"], "description": "Sunset over the beach in Goa", "interests": "travel,beach,sunset", "category": "Travel"},
        {"owner_id": alice["id"], "description": "Street food tour in Lucknow", "interests": "food,streetfood,travel", "category": "Food"},
        {"owner_id": bob["id"], "description": "Stand up comedy clip", "interests": "comedy,funny", "category": "Comedy"},
        {"owner_id": bob["id"], "description": "Morning gym routine", "interests": "fitness,gym,health", "category": "Fitness"},
        {"owner_id": alice["id"], "description": "Hiking trail views in the Himalayas", "interests": "travel,hiking,mountains", "category": "Travel"},
    ]
    for i, data in enumerate(post_data):
        img = create_fake_image(f"post_{i}.png")
        resp = requests.post(
            f"{BASE_URL}/posts/",
            data={k: v for k, v in data.items()},
            files={"file": (img.name, img, "image/png")},
        )
        post = resp.json()
        posts.append(post)
        print(f"Created post {post.get('id')}: {data['description']}")

    print("\n=== 3. Alice likes her own travel post + Bob's fitness post ===")
    requests.post(f"{BASE_URL}/posts/{posts[0]['id']}/like", params={"user_id": alice["id"]})
    requests.post(f"{BASE_URL}/posts/{posts[3]['id']}/like", params={"user_id": alice["id"]})
    print("Liked posts:", posts[0]["id"], posts[3]["id"])

    print("\n=== 4. Similar posts to the Goa beach sunset post ===")
    similar = requests.get(f"{BASE_URL}/posts/{posts[0]['id']}/similar", params={"top_n": 3}).json()
    for p in similar:
        print(f"  Post {p['id']} ({p['category']}): {p['description']}  score={p['score']:.3f}")

    print("\n=== 5. Personalized feed for Alice (interests: travel, food) ===")
    feed = requests.get(f"{BASE_URL}/users/{alice['id']}/feed", params={"top_n": 5}).json()
    for p in feed:
        score = f"{p['score']:.3f}" if p['score'] is not None else "N/A"
        print(f"  Post {p['id']} ({p['category']}): {p['description']}  score={score}")

    print("\n=== 6. Posts filtered by category=Travel ===")
    travel_posts = requests.get(f"{BASE_URL}/posts/category/Travel").json()
    for p in travel_posts:
        print(f"  Post {p['id']}: {p['description']}")


if __name__ == "__main__":
    main()
