"""
Standalone test for the content-based recommendation engine.
Does NOT require the API server or a database — pure logic test.

Run with:
    python test_recommend.py
"""
from types import SimpleNamespace
from app.recommend import ContentRecommender


def make_post(id, description, interests, category, likes_count=0):
    return SimpleNamespace(
        id=id, description=description, interests=interests,
        category=category, likes_count=likes_count,
    )


def main():
    posts = [
        make_post(1, "Sunset over the beach in Goa", "travel,beach,sunset", "Travel", 10),
        make_post(2, "Homemade pasta recipe tutorial", "food,cooking,italian", "Food", 5),
        make_post(3, "Hiking trail views in the Himalayas", "travel,hiking,mountains", "Travel", 8),
        make_post(4, "Stand up comedy clip", "comedy,funny", "Comedy", 20),
        make_post(5, "Street food tour in Lucknow", "food,streetfood,travel", "Food", 15),
    ]

    recommender = ContentRecommender(posts)

    print("--- Similar posts to Post 1 (Goa beach sunset) ---")
    for post, score in recommender.similar_to_post(1, top_n=3):
        print(f"  Post {post.id} ({post.category}): {post.description} | score={score:.3f}")
    assert recommender.similar_to_post(1)[0][0].category == "Travel", "Expected a Travel post to rank first"

    print("\n--- Feed for a user interested in travel & food, who liked Post 1 ---")
    for post, score in recommender.feed_for_user("travel,food", liked_post_ids=[1], top_n=4):
        print(f"  Post {post.id} ({post.category}): {post.description} | score={score:.3f}")

    print("\n--- Feed for a brand-new user with no data (cold start fallback) ---")
    for post, score in recommender.feed_for_user("", liked_post_ids=[], top_n=3):
        print(f"  Post {post.id} ({post.category}): {post.description} | likes={post.likes_count}")

    print("\nAll checks passed.")


if __name__ == "__main__":
    main()
