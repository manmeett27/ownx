# Content-Based Social Media Model

An Instagram-style backend module: users upload a photo or short video along
with a **description**, **interests (tags)**, and a **category** — and the
API recommends content back to users using **content-based filtering**
(TF-IDF + cosine similarity), not just a chronological feed.

## Why content-based filtering?

- No cold-start problem — works immediately, even with zero likes/history,
  because every post already carries rich signals (description + tags + category).
- Matches how a new platform actually looks in its first weeks, before there's
  enough interaction data for collaborative filtering to be useful.

## Project structure

```
content_social_model/
├── app/
│   ├── main.py        # FastAPI app + all endpoints
│   ├── models.py      # SQLAlchemy ORM models (User, Post, Like)
│   ├── schemas.py      # Pydantic request/response schemas
│   ├── database.py     # DB engine/session setup (SQLite by default)
│   └── recommend.py    # Content-based recommendation engine
├── uploads/             # Uploaded images/videos land here
├── test_recommend.py    # Pure-logic test of the recommender (no server needed)
├── test_client.py       # Full end-to-end API test (needs server running)
├── requirements.txt
└── README.md
```

## Getting started — step by step (for beginners)

Follow this in order. Every command below goes into a terminal
(Command Prompt / PowerShell on Windows, Terminal on Mac/Linux).

### 1. Check Python is installed

```bash
python --version
```
If that fails, try `python3 --version`. You need Python 3.9 or higher.
If it's not installed, get it from [python.org](https://www.python.org/downloads/).

### 2. Move into the project folder

Unzip this project, then in your terminal:
```bash
cd path/to/content_social_model
```
(Replace `path/to/` with wherever you unzipped it.)

### 3. Quick sanity check (optional but recommended)

This proves the recommendation logic works, with almost no setup:
```bash
pip install scikit-learn
python test_recommend.py
```
You should see output showing ranked "similar posts" and a personalized feed.
If this prints without errors, the core engine is proven to work.

### 4. Create a virtual environment

This keeps this project's packages separate from everything else on your machine.
```bash
python -m venv venv
```
Then activate it:
- **Windows**: `venv\Scripts\activate`
- **Mac/Linux**: `source venv/bin/activate`

You'll know it worked when you see `(venv)` at the start of your terminal line.

### 5. Install the project's dependencies

```bash
pip install -r requirements.txt
```

> **Using a very new Python version (3.13+)?** Some packages may not have a
> ready-made installer yet for the newest Python, which makes `pip` try to
> compile them from source and fail with errors mentioning `meson`,
> `subprocess-exited-with-error`, or `Cython`. If that happens, run:
> ```bash
> pip install --upgrade pip
> pip install scikit-learn
> pip install fastapi "uvicorn[standard]" sqlalchemy python-multipart "pydantic[email]" requests
> ```
> This lets pip fetch the latest version of each package instead of an old
> pinned one, which usually fixes it immediately.

Confirm everything installed correctly:
```bash
python -c "import fastapi, sqlalchemy, sklearn; print('all good')"
```

### 6. Start the server

```bash
uvicorn app.main:app --reload
```
Wait for a line that says `Application startup complete.` — **leave this
terminal window open**; closing it stops the server.

### 7. Open the interactive docs in your browser

Go to:
```
http://127.0.0.1:8000/docs
```
You'll see every endpoint listed (Users, Posts, Recommendations, Health),
each expandable with a "Try it out" button.

### 8. Try it out — create a user

1. Click **POST /users/ Create User** to expand it
2. Click **"Try it out"**
3. Replace the sample JSON with:
   ```json
   {
     "username": "alice",
     "email": "alice@example.com",
     "interests": ["travel", "food"]
   }
   ```
4. Click the blue **"Execute"** button
5. Scroll down to **"Server response"** — you'll see the created user with an `id`

### 9. Try it out — upload a post

1. Click **POST /posts/ Create Post** to expand it, then **"Try it out"**
2. Fill in `owner_id` (the `id` from step 8), `description`, `interests`
   (comma-separated, e.g. `travel,beach`), `category` (e.g. `Travel`)
3. Click **"Choose File"** and pick any image or short video
4. Click **"Execute"** and check the response

### 10. Try the recommendations

- **GET /posts/{post_id}/similar** — see content-similar posts to one you just made
- **GET /users/{user_id}/feed** — see a personalized feed for that user

### 11. Run the full automated test (does steps 8-10 for you, instantly)

Open a **second terminal window** (keep the server running in the first one):
```bash
cd path/to/content_social_model
source venv/bin/activate      # or venv\Scripts\activate on Windows
pip install requests
python test_client.py
```
This creates 2 users, uploads 5 posts, likes some, then prints similar-post
recommendations, a personalized feed, and category filtering — all automatically.

## Troubleshooting

| Problem | Fix |
|---|---|
| `pip install` fails with `meson`/`Cython`/`subprocess-exited-with-error` | Your Python version is too new for a pinned package version. Run `pip install --upgrade pip` then install packages without version numbers (see step 5). |
| `python` command not found | Try `python3` and `pip3` instead — common on Mac. |
| Browser can't reach `127.0.0.1:8000/docs` | Make sure the terminal running `uvicorn` is still open and shows no errors. |
| `ModuleNotFoundError` when running a script | Make sure your virtual environment is activated — you should see `(venv)` in the terminal prompt. |

## Key endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/users/` | Create a user (with interests) |
| POST | `/posts/` | Upload image/video + description + interests + category |
| GET | `/posts/` | List all posts |
| GET | `/posts/category/{category}` | Filter posts by category |
| POST | `/posts/{id}/like` | Like a post |
| GET | `/posts/{id}/similar` | Content-based "similar posts" |
| GET | `/users/{id}/feed` | Personalized, content-based feed |

## How the recommender works (`app/recommend.py`)

1. Every post becomes a text document: `description + interests + category`.
2. All post documents are vectorized with **TF-IDF**.
3. **Similar posts** = nearest neighbors by cosine similarity to a post's vector.
4. **Personalized feed** = build a query vector from the user's declared
   interests plus the content of posts they've liked, then rank every post
   by similarity to that query.
5. If a user has no interests and no likes yet, it falls back to
   most-liked posts so the feed is never empty.

## Swapping to Postgres/MySQL for production

Only one line needs to change — `SQLALCHEMY_DATABASE_URL` in `app/database.py`.
Everything else (models, endpoints, recommender) stays the same.

## Pushing to your team's GitHub repo

```bash
git init
git add .
git commit -m "Add content-based social media upload + recommendation model"
git remote add origin <your-team-repo-url>
git branch -M main
git push -u origin main
```

If the repo already exists and has commits, instead do:
```bash
git remote add origin <your-team-repo-url>
git pull origin main --allow-unrelated-histories
git add .
git commit -m "Add content-based social media upload + recommendation model"
git push origin main
```
